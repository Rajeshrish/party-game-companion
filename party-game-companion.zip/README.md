# Party Game Companion

A browser app for running an in-person party game night: the host spins
game wheels, manages teams and keeps score, and players follow along on
their own phones.

- **Host:** create a party, admit players, assign teams, spin the
  Multiplayer and 1v1 wheels, track rounds, award points
- **Players:** join with a 5-letter code, see their score, rank, team
  and the current game

Open `index.html` to run it. To let friends join from their own phones
without accounts, follow **SETUP.md** (free Firebase project, ~15 min).
